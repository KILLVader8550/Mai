function handleClick() {
    var page1 = document.getElementById("start");
    var page2 = document.getElementById("area");
    
    if (page1.classList.contains("active")) {
      start.classList.remove("active");
      area.classList.add("active");
    } else {
      area.classList.remove("active");
      start.classList.add("active");
    }
    
    // Remove the event listener after the transition has occurred once
    document.body.removeEventListener('click', handleClick);
  }
  
  document.body.addEventListener('click', handleClick);
  